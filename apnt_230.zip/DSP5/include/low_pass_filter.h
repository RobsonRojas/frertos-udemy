#ifndef LOW_PASS_FILTER_H

  #define LOW_PASS_FILTER_H
	
  void low_pass_filter_init(void);
  q15_t low_pass_filter(q15_t *input);

#endif
